﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace INotifyDemo
{
    class Student : INotifyPropertyChanged
    {
        private string name;

        public string Name
        {
            get { return name; }
            set
            {
                name = value;
                NotiftPropertyChanged("Name");
            }
        }

        private int age;

        public int Age
        {
            get { return age; }
            set
            {
                age = value;
                NotiftPropertyChanged("Age");
            }
        }

        private void NotiftPropertyChanged(string name)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(name));
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;
    }
}
