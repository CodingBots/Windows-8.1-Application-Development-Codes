﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace JsonDemo
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            List<Student> list = new List<Student>();
            Student s;
            for (int i = 0; i < 10; i++)
            {
                s = new Student();
                s.ID = i + 12;
                s.Age = i + 21;
                s.Name = "Student " + i;
                list.Add(s);
            }

            string json = JsonConvert.SerializeObject(list, Formatting.Indented);
            StorageFolder folder = await ApplicationData.Current.LocalFolder.CreateFolderAsync("LocalDBFolder",
                CreationCollisionOption.ReplaceExisting);
            StorageFile jsonFile = await folder.CreateFileAsync("StudentsList.txt",
                CreationCollisionOption.ReplaceExisting);
            //StorageFile jsonFile = await ApplicationData.Current.LocalFolder.CreateFileAsync("StudentsList.txt");
            await FileIO.WriteTextAsync(jsonFile, json);

            txtJson.Text = json;
        }

        private async void Button_Click_1(object sender, RoutedEventArgs e)
        {
            StorageFolder folder = await ApplicationData.Current.LocalFolder.GetFolderAsync("LocalDBFolder");
            //StorageFile file = await folder.GetFileAsync("StudentsList.txt");
            //await file.DeleteAsync();
            await folder.DeleteAsync();

            //List<Student> newList = new List<Student>();
            //string json = txtJson.Text;
            //newList = JsonConvert.DeserializeObject<List<Student>>(json);

        }
    }
}
