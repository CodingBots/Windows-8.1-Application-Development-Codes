﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace ListDemo
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        ObservableCollection<Student> studentList;
        string imageName;
        public MainPage()
        {
            this.InitializeComponent();
            Loaded += MainPage_Loaded;
        }

        async void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            if (studentList == null)
                studentList = new ObservableCollection<Student>();

            try
            {
                StorageFile file = await ApplicationData.Current.LocalFolder.GetFileAsync("Students.txt");
                string studentJson = await FileIO.ReadTextAsync(file);
                studentList = JsonConvert.DeserializeObject<ObservableCollection<Student>>(studentJson);
            }
            catch (Exception)
            {
            }
            finally
            {
                myListView.DataContext = studentList;
            }
        }

        private async void myGridView_Tapped(object sender, TappedRoutedEventArgs e)
        {
            if (myListView.SelectedIndex != -1)
            {
                Student s = myListView.SelectedItem as Student;
                await new MessageDialog("You have selected student " + s.Name).ShowAsync();
                //this.Frame.Navigate(typeof(), s);
            }
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            Student s = new Student();
            s.Name = txtName.Text;
            s.Age = int.Parse(txtAge.Text);
            s.Image = "ms-appdata:///local/" + imageName;
            studentList.Add(s);

            string json = JsonConvert.SerializeObject(studentList, Formatting.Indented);
            StorageFile file = await ApplicationData.Current.LocalFolder.CreateFileAsync("Students.txt", CreationCollisionOption.ReplaceExisting);
            await FileIO.WriteTextAsync(file, json);

            txtName.Text = "";
            txtAge.Text = "";
            imageName = "";
        }

        private async void Button_Click_1(object sender, RoutedEventArgs e)
        {
            FileOpenPicker picker = new FileOpenPicker();
            picker.SuggestedStartLocation = PickerLocationId.Desktop;
            picker.ViewMode = PickerViewMode.Thumbnail;
            picker.FileTypeFilter.Add(".png");
            picker.FileTypeFilter.Add(".jpg");

            StorageFile originalFile = await picker.PickSingleFileAsync();
            StorageFile newFile = await ApplicationData.Current.LocalFolder.CreateFileAsync(originalFile.Name);
            imageName = originalFile.Name;
            await originalFile.CopyAndReplaceAsync(newFile);
        }
    }
}
