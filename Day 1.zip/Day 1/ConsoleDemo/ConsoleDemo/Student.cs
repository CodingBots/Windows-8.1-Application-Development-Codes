﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleDemo
{
    public class Student : IStudent
    {
        public string name { get; set; }

        public int Age { get; set; }

        public void Name()
        {
        }
    }
}
