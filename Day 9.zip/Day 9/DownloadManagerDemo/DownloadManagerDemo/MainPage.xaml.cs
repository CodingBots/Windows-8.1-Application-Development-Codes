﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Networking.BackgroundTransfer;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace DownloadManagerDemo
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            FileSavePicker picker = new FileSavePicker();
            List<string> type = new List<string>();



            type.Add(txtLink.Text.Substring(txtLink.Text.LastIndexOf(".")));

            picker.FileTypeChoices.Add("Files", type);
            StorageFile file = await picker.PickSaveFileAsync();

            // Download
            BackgroundDownloader downloader = new BackgroundDownloader();
            DownloadOperation downloadOperation = downloader.CreateDownload(new Uri(txtLink.Text), file);
            Progress<DownloadOperation> progress = new Progress<DownloadOperation>(MyDownloadProgress);
            await downloadOperation.StartAsync().AsTask(progress);
            await new MessageDialog("Download Completed").ShowAsync();
        }

        private void MyDownloadProgress(DownloadOperation obj)
        {
            ulong recieved = obj.Progress.BytesReceived;
            ulong totalBytes = obj.Progress.TotalBytesToReceive;

            double progress = (double)(recieved / totalBytes);
            myProgressBar.Value = progress * 100;
        }
    }
}
